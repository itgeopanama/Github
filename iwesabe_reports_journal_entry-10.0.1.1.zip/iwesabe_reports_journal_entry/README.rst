Report Journal Entry v10
=============================
This module adds a new button in the form of journal entry to print.
